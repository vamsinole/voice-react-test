import React, { useState } from 'react'
import '../Login/Styles.scss'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'


const Register = () => {
  

  
  return (
    <>
    
    </>
  )
}

export default Register