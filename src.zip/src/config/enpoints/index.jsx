export const USER_ENDPOINTS = {
    agentdata: `/v1/agents`,
    getUsers: `/v1/users`,
    getCustomer: `/v1/users`,
    getKnowledge:`/v1/knowledge_base`,
    getvoicecall:`/v1/voicecalls/`
   

  };