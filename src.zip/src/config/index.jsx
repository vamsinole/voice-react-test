const env={
     baseUrl:'http://146.148.89.120',
    // baseUrlLocal:'http://'+window.location.host || env.baseUrl,
    //baseUrl:'http://'+window.location.host || env.baseUrl,
}

export default env;